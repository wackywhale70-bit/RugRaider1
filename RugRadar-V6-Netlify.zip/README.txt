RugRadar V6 – Netlify
ZIP entpacken. Inhalt (nicht den ZIP oder aeusseren Ordner) in GitHub hochladen.
Im Repository muessen index.html, logo.webp, netlify.toml und netlify/functions/rpc.mjs vorhanden sein.
Netlify: Base directory leer, Build command: mkdir -p public && cp index.html logo.webp public/
Publish directory: public; Functions directory: netlify/functions.
Der Build erstellt public automatisch. Optional Helius Mainnet RPC URL als SOLANA_RPC_URL fuer Functions hinterlegen. Niemals in GitHub speichern.
Deploy erneut starten. Wrapped SOL testen. Live-APIs nicht getestet; kostenlose RPCs haben Limits.
